package hae.basic.board.model;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 1. 6.
 * @see
 */

@Data
public class Person {
    private Integer id;
    private String name;
}
