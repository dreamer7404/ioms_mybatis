package hae.basic.biz.dao;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 1. 19.
 * @see
 */

@Data
public class UsrLogin {
    private String userId;
    private String userPw;
}
